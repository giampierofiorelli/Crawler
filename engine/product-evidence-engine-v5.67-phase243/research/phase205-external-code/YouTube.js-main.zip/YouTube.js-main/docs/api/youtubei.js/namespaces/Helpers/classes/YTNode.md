[youtubei.js](../../../../README.md) / [Helpers](../README.md) / YTNode

# Class: YTNode

Defined in: [src/parser/helpers.ts:6](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/helpers.ts#L6)

## Extended by

- [`ItemSectionContinuation`](../../../../classes/ItemSectionContinuation.md)
- [`NavigateAction`](../../../../classes/NavigateAction.md)
- [`ShowMiniplayerCommand`](../../../../classes/ShowMiniplayerCommand.md)
- [`ReloadContinuationItemsCommand`](../../../../classes/ReloadContinuationItemsCommand.md)
- [`SectionListContinuation`](../../../../classes/SectionListContinuation.md)
- [`MusicPlaylistShelfContinuation`](../../../../classes/MusicPlaylistShelfContinuation.md)
- [`MusicShelfContinuation`](../../../../classes/MusicShelfContinuation.md)
- [`GridContinuation`](../../../../classes/GridContinuation.md)
- [`PlaylistPanelContinuation`](../../../../classes/PlaylistPanelContinuation.md)
- [`Continuation`](../../../../classes/Continuation.md)
- [`LiveChatContinuation`](../../../../classes/LiveChatContinuation.md)
- [`ContinuationCommand`](../../../../classes/ContinuationCommand.md)
- [`AppendContinuationItemsAction`](../../../../classes/AppendContinuationItemsAction.md)
- [`ChildElement`](../../Misc/classes/ChildElement.md)
- [`AboutChannel`](../../YTNodes/classes/AboutChannel.md)
- [`AboutChannelView`](../../YTNodes/classes/AboutChannelView.md)
- [`AccountChannel`](../../YTNodes/classes/AccountChannel.md)
- [`AccountItem`](../../YTNodes/classes/AccountItem.md)
- [`AccountItemSection`](../../YTNodes/classes/AccountItemSection.md)
- [`AccountItemSectionHeader`](../../YTNodes/classes/AccountItemSectionHeader.md)
- [`AccountSectionList`](../../YTNodes/classes/AccountSectionList.md)
- [`ChangeEngagementPanelVisibilityAction`](../../YTNodes/classes/ChangeEngagementPanelVisibilityAction.md)
- [`GetMultiPageMenuAction`](../../YTNodes/classes/GetMultiPageMenuAction.md)
- [`OpenPopupAction`](../../YTNodes/classes/OpenPopupAction.md)
- [`SendFeedbackAction`](../../YTNodes/classes/SendFeedbackAction.md)
- [`SignalAction`](../../YTNodes/classes/SignalAction.md)
- [`UpdateChannelSwitcherPageAction`](../../YTNodes/classes/UpdateChannelSwitcherPageAction.md)
- [`UpdateEngagementPanelAction`](../../YTNodes/classes/UpdateEngagementPanelAction.md)
- [`UpdateSubscribeButtonAction`](../../YTNodes/classes/UpdateSubscribeButtonAction.md)
- [`ActiveAccountHeader`](../../YTNodes/classes/ActiveAccountHeader.md)
- [`AddToPlaylist`](../../YTNodes/classes/AddToPlaylist.md)
- [`Alert`](../../YTNodes/classes/Alert.md)
- [`AlertWithButton`](../../YTNodes/classes/AlertWithButton.md)
- [`AnimatedThumbnailOverlayView`](../../YTNodes/classes/AnimatedThumbnailOverlayView.md)
- [`AttributionView`](../../YTNodes/classes/AttributionView.md)
- [`AudioOnlyPlayability`](../../YTNodes/classes/AudioOnlyPlayability.md)
- [`AutomixPreviewVideo`](../../YTNodes/classes/AutomixPreviewVideo.md)
- [`AvatarStackView`](../../YTNodes/classes/AvatarStackView.md)
- [`AvatarView`](../../YTNodes/classes/AvatarView.md)
- [`BackgroundPromo`](../../YTNodes/classes/BackgroundPromo.md)
- [`BackstageImage`](../../YTNodes/classes/BackstageImage.md)
- [`BackstagePost`](../../YTNodes/classes/BackstagePost.md)
- [`BackstagePostThread`](../../YTNodes/classes/BackstagePostThread.md)
- [`BadgeView`](../../YTNodes/classes/BadgeView.md)
- [`BrowseFeedActions`](../../YTNodes/classes/BrowseFeedActions.md)
- [`BrowserMediaSession`](../../YTNodes/classes/BrowserMediaSession.md)
- [`Button`](../../YTNodes/classes/Button.md)
- [`ButtonCardView`](../../YTNodes/classes/ButtonCardView.md)
- [`ButtonView`](../../YTNodes/classes/ButtonView.md)
- [`C4TabbedHeader`](../../YTNodes/classes/C4TabbedHeader.md)
- [`CallToActionButton`](../../YTNodes/classes/CallToActionButton.md)
- [`Card`](../../YTNodes/classes/Card.md)
- [`CardCollection`](../../YTNodes/classes/CardCollection.md)
- [`CarouselHeader`](../../YTNodes/classes/CarouselHeader.md)
- [`CarouselItem`](../../YTNodes/classes/CarouselItem.md)
- [`CarouselItemView`](../../YTNodes/classes/CarouselItemView.md)
- [`CarouselLockup`](../../YTNodes/classes/CarouselLockup.md)
- [`CarouselTitleView`](../../YTNodes/classes/CarouselTitleView.md)
- [`Channel`](../../YTNodes/classes/Channel.md)
- [`ChannelAboutFullMetadata`](../../YTNodes/classes/ChannelAboutFullMetadata.md)
- [`ChannelAgeGate`](../../YTNodes/classes/ChannelAgeGate.md)
- [`ChannelExternalLinkView`](../../YTNodes/classes/ChannelExternalLinkView.md)
- [`ChannelFeaturedContent`](../../YTNodes/classes/ChannelFeaturedContent.md)
- [`ChannelHeaderLinks`](../../YTNodes/classes/ChannelHeaderLinks.md)
- [`ChannelHeaderLinksView`](../../YTNodes/classes/ChannelHeaderLinksView.md)
- [`ChannelMetadata`](../../YTNodes/classes/ChannelMetadata.md)
- [`ChannelMobileHeader`](../../YTNodes/classes/ChannelMobileHeader.md)
- [`ChannelOptions`](../../YTNodes/classes/ChannelOptions.md)
- [`ChannelOwnerEmptyState`](../../YTNodes/classes/ChannelOwnerEmptyState.md)
- [`ChannelSubMenu`](../../YTNodes/classes/ChannelSubMenu.md)
- [`ChannelSwitcherHeader`](../../YTNodes/classes/ChannelSwitcherHeader.md)
- [`ChannelSwitcherPage`](../../YTNodes/classes/ChannelSwitcherPage.md)
- [`ChannelTagline`](../../YTNodes/classes/ChannelTagline.md)
- [`ChannelThumbnailWithLink`](../../YTNodes/classes/ChannelThumbnailWithLink.md)
- [`ChannelVideoPlayer`](../../YTNodes/classes/ChannelVideoPlayer.md)
- [`Chapter`](../../YTNodes/classes/Chapter.md)
- [`ChildVideo`](../../YTNodes/classes/ChildVideo.md)
- [`ChipBarView`](../../YTNodes/classes/ChipBarView.md)
- [`ChipCloud`](../../YTNodes/classes/ChipCloud.md)
- [`ChipCloudChip`](../../YTNodes/classes/ChipCloudChip.md)
- [`ChipView`](../../YTNodes/classes/ChipView.md)
- [`ClientSideToggleMenuItem`](../../YTNodes/classes/ClientSideToggleMenuItem.md)
- [`ClipAdState`](../../YTNodes/classes/ClipAdState.md)
- [`ClipCreation`](../../YTNodes/classes/ClipCreation.md)
- [`ClipCreationScrubber`](../../YTNodes/classes/ClipCreationScrubber.md)
- [`ClipCreationTextInput`](../../YTNodes/classes/ClipCreationTextInput.md)
- [`ClipSection`](../../YTNodes/classes/ClipSection.md)
- [`CollaboratorInfoCardContent`](../../YTNodes/classes/CollaboratorInfoCardContent.md)
- [`CollageHeroImage`](../../YTNodes/classes/CollageHeroImage.md)
- [`CollectionThumbnailView`](../../YTNodes/classes/CollectionThumbnailView.md)
- [`AddToPlaylistCommand`](../../YTNodes/classes/AddToPlaylistCommand.md)
- [`CommandExecutorCommand`](../../YTNodes/classes/CommandExecutorCommand.md)
- [`ContinuationCommand`](../../YTNodes/classes/ContinuationCommand.md)
- [`GetKidsBlocklistPickerCommand`](../../YTNodes/classes/GetKidsBlocklistPickerCommand.md)
- [`RunAttestationCommand`](../../YTNodes/classes/RunAttestationCommand.md)
- [`ShowDialogCommand`](../../YTNodes/classes/ShowDialogCommand.md)
- [`ShowSheetCommand`](../../YTNodes/classes/ShowSheetCommand.md)
- [`UpdateEngagementPanelContentCommand`](../../YTNodes/classes/UpdateEngagementPanelContentCommand.md)
- [`AuthorCommentBadge`](../../YTNodes/classes/AuthorCommentBadge.md)
- [`CommentActionButtons`](../../YTNodes/classes/CommentActionButtons.md)
- [`CommentDialog`](../../YTNodes/classes/CommentDialog.md)
- [`CommentReplies`](../../YTNodes/classes/CommentReplies.md)
- [`CommentReplyDialog`](../../YTNodes/classes/CommentReplyDialog.md)
- [`CommentsEntryPointHeader`](../../YTNodes/classes/CommentsEntryPointHeader.md)
- [`CommentsEntryPointTeaser`](../../YTNodes/classes/CommentsEntryPointTeaser.md)
- [`CommentsHeader`](../../YTNodes/classes/CommentsHeader.md)
- [`CommentSimplebox`](../../YTNodes/classes/CommentSimplebox.md)
- [`CommentsSimplebox`](../../YTNodes/classes/CommentsSimplebox.md)
- [`CommentThread`](../../YTNodes/classes/CommentThread.md)
- [`CommentView`](../../YTNodes/classes/CommentView.md)
- [`CreatorHeart`](../../YTNodes/classes/CreatorHeart.md)
- [`EmojiPicker`](../../YTNodes/classes/EmojiPicker.md)
- [`PdgCommentChip`](../../YTNodes/classes/PdgCommentChip.md)
- [`SponsorCommentBadge`](../../YTNodes/classes/SponsorCommentBadge.md)
- [`VoiceReplyContainerView`](../../YTNodes/classes/VoiceReplyContainerView.md)
- [`CompactChannel`](../../YTNodes/classes/CompactChannel.md)
- [`CompactLink`](../../YTNodes/classes/CompactLink.md)
- [`CompactMovie`](../../YTNodes/classes/CompactMovie.md)
- [`CompactStation`](../../YTNodes/classes/CompactStation.md)
- [`CompactVideo`](../../YTNodes/classes/CompactVideo.md)
- [`CompositeVideoPrimaryInfo`](../../YTNodes/classes/CompositeVideoPrimaryInfo.md)
- [`ConfirmDialog`](../../YTNodes/classes/ConfirmDialog.md)
- [`ContentListItemView`](../../YTNodes/classes/ContentListItemView.md)
- [`ContentMetadataView`](../../YTNodes/classes/ContentMetadataView.md)
- [`ContentPreviewImageView`](../../YTNodes/classes/ContentPreviewImageView.md)
- [`ContinuationItem`](../../YTNodes/classes/ContinuationItem.md)
- [`ContinuationItemView`](../../YTNodes/classes/ContinuationItemView.md)
- [`ConversationBar`](../../YTNodes/classes/ConversationBar.md)
- [`CopyLink`](../../YTNodes/classes/CopyLink.md)
- [`CreatePlaylistDialog`](../../YTNodes/classes/CreatePlaylistDialog.md)
- [`CreatePlaylistDialogFormView`](../../YTNodes/classes/CreatePlaylistDialogFormView.md)
- [`DecoratedAvatarView`](../../YTNodes/classes/DecoratedAvatarView.md)
- [`DecoratedPlayerBar`](../../YTNodes/classes/DecoratedPlayerBar.md)
- [`DefaultPromoPanel`](../../YTNodes/classes/DefaultPromoPanel.md)
- [`DescriptionPreviewView`](../../YTNodes/classes/DescriptionPreviewView.md)
- [`DialogHeaderView`](../../YTNodes/classes/DialogHeaderView.md)
- [`DialogView`](../../YTNodes/classes/DialogView.md)
- [`DidYouMean`](../../YTNodes/classes/DidYouMean.md)
- [`DislikeButtonView`](../../YTNodes/classes/DislikeButtonView.md)
- [`DismissableDialog`](../../YTNodes/classes/DismissableDialog.md)
- [`DismissableDialogContentSection`](../../YTNodes/classes/DismissableDialogContentSection.md)
- [`DownloadButton`](../../YTNodes/classes/DownloadButton.md)
- [`DownloadListItemView`](../../YTNodes/classes/DownloadListItemView.md)
- [`Dropdown`](../../YTNodes/classes/Dropdown.md)
- [`DropdownItem`](../../YTNodes/classes/DropdownItem.md)
- [`DropdownView`](../../YTNodes/classes/DropdownView.md)
- [`DynamicTextView`](../../YTNodes/classes/DynamicTextView.md)
- [`Element`](../../YTNodes/classes/Element.md)
- [`EmergencyOnebox`](../../YTNodes/classes/EmergencyOnebox.md)
- [`EmojiPickerCategory`](../../YTNodes/classes/EmojiPickerCategory.md)
- [`EmojiPickerCategoryButton`](../../YTNodes/classes/EmojiPickerCategoryButton.md)
- [`EmojiPickerUpsellCategory`](../../YTNodes/classes/EmojiPickerUpsellCategory.md)
- [`AddToPlaylistServiceEndpoint`](../../YTNodes/classes/AddToPlaylistServiceEndpoint.md)
- [`BrowseEndpoint`](../../YTNodes/classes/BrowseEndpoint.md)
- [`CreateCommentEndpoint`](../../YTNodes/classes/CreateCommentEndpoint.md)
- [`CreatePlaylistServiceEndpoint`](../../YTNodes/classes/CreatePlaylistServiceEndpoint.md)
- [`DeletePlaylistEndpoint`](../../YTNodes/classes/DeletePlaylistEndpoint.md)
- [`FeedbackEndpoint`](../../YTNodes/classes/FeedbackEndpoint.md)
- [`GetAccountsListInnertubeEndpoint`](../../YTNodes/classes/GetAccountsListInnertubeEndpoint.md)
- [`HideEngagementPanelEndpoint`](../../YTNodes/classes/HideEngagementPanelEndpoint.md)
- [`LikeEndpoint`](../../YTNodes/classes/LikeEndpoint.md)
- [`LiveChatItemContextMenuEndpoint`](../../YTNodes/classes/LiveChatItemContextMenuEndpoint.md)
- [`ModifyChannelNotificationPreferenceEndpoint`](../../YTNodes/classes/ModifyChannelNotificationPreferenceEndpoint.md)
- [`PerformCommentActionEndpoint`](../../YTNodes/classes/PerformCommentActionEndpoint.md)
- [`PlaylistEditEndpoint`](../../YTNodes/classes/PlaylistEditEndpoint.md)
- [`ReelWatchEndpoint`](../../YTNodes/classes/ReelWatchEndpoint.md)
- [`SearchEndpoint`](../../YTNodes/classes/SearchEndpoint.md)
- [`ShareEntityServiceEndpoint`](../../YTNodes/classes/ShareEntityServiceEndpoint.md)
- [`ShowEngagementPanelEndpoint`](../../YTNodes/classes/ShowEngagementPanelEndpoint.md)
- [`SignalServiceEndpoint`](../../YTNodes/classes/SignalServiceEndpoint.md)
- [`SubscribeEndpoint`](../../YTNodes/classes/SubscribeEndpoint.md)
- [`UnsubscribeEndpoint`](../../YTNodes/classes/UnsubscribeEndpoint.md)
- [`WatchEndpoint`](../../YTNodes/classes/WatchEndpoint.md)
- [`WatchNextEndpoint`](../../YTNodes/classes/WatchNextEndpoint.md)
- [`Endscreen`](../../YTNodes/classes/Endscreen.md)
- [`EndscreenElement`](../../YTNodes/classes/EndscreenElement.md)
- [`EndScreenPlaylist`](../../YTNodes/classes/EndScreenPlaylist.md)
- [`EndScreenVideo`](../../YTNodes/classes/EndScreenVideo.md)
- [`EngagementPanelSectionList`](../../YTNodes/classes/EngagementPanelSectionList.md)
- [`EngagementPanelTitleHeader`](../../YTNodes/classes/EngagementPanelTitleHeader.md)
- [`EomSettingsDisclaimer`](../../YTNodes/classes/EomSettingsDisclaimer.md)
- [`ExpandableMetadata`](../../YTNodes/classes/ExpandableMetadata.md)
- [`ExpandableTab`](../../YTNodes/classes/ExpandableTab.md)
- [`ExpandableVideoDescriptionBody`](../../YTNodes/classes/ExpandableVideoDescriptionBody.md)
- [`ExpandedShelfContents`](../../YTNodes/classes/ExpandedShelfContents.md)
- [`Factoid`](../../YTNodes/classes/Factoid.md)
- [`FancyDismissibleDialog`](../../YTNodes/classes/FancyDismissibleDialog.md)
- [`FeedFilterChipBar`](../../YTNodes/classes/FeedFilterChipBar.md)
- [`FeedNudge`](../../YTNodes/classes/FeedNudge.md)
- [`FeedTabbedHeader`](../../YTNodes/classes/FeedTabbedHeader.md)
- [`FlexibleActionsView`](../../YTNodes/classes/FlexibleActionsView.md)
- [`Form`](../../YTNodes/classes/Form.md)
- [`FormFooterView`](../../YTNodes/classes/FormFooterView.md)
- [`FormPopup`](../../YTNodes/classes/FormPopup.md)
- [`GameCard`](../../YTNodes/classes/GameCard.md)
- [`GameDetails`](../../YTNodes/classes/GameDetails.md)
- [`Grid`](../../YTNodes/classes/Grid.md)
- [`GridChannel`](../../YTNodes/classes/GridChannel.md)
- [`GridHeader`](../../YTNodes/classes/GridHeader.md)
- [`GridMix`](../../YTNodes/classes/GridMix.md)
- [`GridMovie`](../../YTNodes/classes/GridMovie.md)
- [`GridPlaylist`](../../YTNodes/classes/GridPlaylist.md)
- [`GridShelfView`](../../YTNodes/classes/GridShelfView.md)
- [`GridShow`](../../YTNodes/classes/GridShow.md)
- [`GridVideo`](../../YTNodes/classes/GridVideo.md)
- [`GuideCollapsibleEntry`](../../YTNodes/classes/GuideCollapsibleEntry.md)
- [`GuideCollapsibleSectionEntry`](../../YTNodes/classes/GuideCollapsibleSectionEntry.md)
- [`GuideEntry`](../../YTNodes/classes/GuideEntry.md)
- [`GuideSection`](../../YTNodes/classes/GuideSection.md)
- [`HashtagHeader`](../../YTNodes/classes/HashtagHeader.md)
- [`HashtagTile`](../../YTNodes/classes/HashtagTile.md)
- [`Heatmap`](../../YTNodes/classes/Heatmap.md)
- [`HeatMarker`](../../YTNodes/classes/HeatMarker.md)
- [`HeroPlaylistThumbnail`](../../YTNodes/classes/HeroPlaylistThumbnail.md)
- [`HighlightsCarousel`](../../YTNodes/classes/HighlightsCarousel.md)
- [`HorizontalCardList`](../../YTNodes/classes/HorizontalCardList.md)
- [`HorizontalList`](../../YTNodes/classes/HorizontalList.md)
- [`HorizontalMovieList`](../../YTNodes/classes/HorizontalMovieList.md)
- [`HowThisWasMadeSectionView`](../../YTNodes/classes/HowThisWasMadeSectionView.md)
- [`HypeFanCreditsSectionView`](../../YTNodes/classes/HypeFanCreditsSectionView.md)
- [`HypePointsFactoid`](../../YTNodes/classes/HypePointsFactoid.md)
- [`IconLink`](../../YTNodes/classes/IconLink.md)
- [`ImageBannerView`](../../YTNodes/classes/ImageBannerView.md)
- [`IncludingResultsFor`](../../YTNodes/classes/IncludingResultsFor.md)
- [`InfoPanelContainer`](../../YTNodes/classes/InfoPanelContainer.md)
- [`InfoPanelContent`](../../YTNodes/classes/InfoPanelContent.md)
- [`InfoRow`](../../YTNodes/classes/InfoRow.md)
- [`InteractiveTabbedHeader`](../../YTNodes/classes/InteractiveTabbedHeader.md)
- [`ItemSection`](../../YTNodes/classes/ItemSection.md)
- [`ItemSectionHeader`](../../YTNodes/classes/ItemSectionHeader.md)
- [`ItemSectionTab`](../../YTNodes/classes/ItemSectionTab.md)
- [`ItemSectionTabbedHeader`](../../YTNodes/classes/ItemSectionTabbedHeader.md)
- [`LikeButton`](../../YTNodes/classes/LikeButton.md)
- [`LikeButtonView`](../../YTNodes/classes/LikeButtonView.md)
- [`ListItemView`](../../YTNodes/classes/ListItemView.md)
- [`ListView`](../../YTNodes/classes/ListView.md)
- [`LiveChat`](../../YTNodes/classes/LiveChat.md)
- [`AddBannerToLiveChatCommand`](../../YTNodes/classes/AddBannerToLiveChatCommand.md)
- [`AddChatItemAction`](../../YTNodes/classes/AddChatItemAction.md)
- [`AddLiveChatTickerItemAction`](../../YTNodes/classes/AddLiveChatTickerItemAction.md)
- [`DimChatItemAction`](../../YTNodes/classes/DimChatItemAction.md)
- [`BumperUserEduContentView`](../../YTNodes/classes/BumperUserEduContentView.md)
- [`CreatorHeartView`](../../YTNodes/classes/CreatorHeartView.md)
- [`LiveChatAutoModMessage`](../../YTNodes/classes/LiveChatAutoModMessage.md)
- [`LiveChatBanner`](../../YTNodes/classes/LiveChatBanner.md)
- [`LiveChatBannerChatSummary`](../../YTNodes/classes/LiveChatBannerChatSummary.md)
- [`LiveChatBannerHeader`](../../YTNodes/classes/LiveChatBannerHeader.md)
- [`LiveChatBannerPoll`](../../YTNodes/classes/LiveChatBannerPoll.md)
- [`LiveChatBannerRedirect`](../../YTNodes/classes/LiveChatBannerRedirect.md)
- [`LiveChatItemBumperView`](../../YTNodes/classes/LiveChatItemBumperView.md)
- [`LiveChatMembershipItem`](../../YTNodes/classes/LiveChatMembershipItem.md)
- [`LiveChatModeChangeMessage`](../../YTNodes/classes/LiveChatModeChangeMessage.md)
- [`LiveChatPaidMessage`](../../YTNodes/classes/LiveChatPaidMessage.md)
- [`LiveChatPaidSticker`](../../YTNodes/classes/LiveChatPaidSticker.md)
- [`LiveChatPlaceholderItem`](../../YTNodes/classes/LiveChatPlaceholderItem.md)
- [`LiveChatProductItem`](../../YTNodes/classes/LiveChatProductItem.md)
- [`LiveChatRestrictedParticipation`](../../YTNodes/classes/LiveChatRestrictedParticipation.md)
- [`LiveChatSponsorshipsGiftPurchaseAnnouncement`](../../YTNodes/classes/LiveChatSponsorshipsGiftPurchaseAnnouncement.md)
- [`LiveChatSponsorshipsGiftRedemptionAnnouncement`](../../YTNodes/classes/LiveChatSponsorshipsGiftRedemptionAnnouncement.md)
- [`LiveChatSponsorshipsHeader`](../../YTNodes/classes/LiveChatSponsorshipsHeader.md)
- [`LiveChatTextMessage`](../../YTNodes/classes/LiveChatTextMessage.md)
- [`LiveChatTickerPaidMessageItem`](../../YTNodes/classes/LiveChatTickerPaidMessageItem.md)
- [`LiveChatTickerPaidStickerItem`](../../YTNodes/classes/LiveChatTickerPaidStickerItem.md)
- [`LiveChatTickerSponsorItem`](../../YTNodes/classes/LiveChatTickerSponsorItem.md)
- [`LiveChatViewerEngagementMessage`](../../YTNodes/classes/LiveChatViewerEngagementMessage.md)
- [`PdgReplyButtonView`](../../YTNodes/classes/PdgReplyButtonView.md)
- [`PollHeader`](../../YTNodes/classes/PollHeader.md)
- [`LiveChatActionPanel`](../../YTNodes/classes/LiveChatActionPanel.md)
- [`MarkChatItemAsDeletedAction`](../../YTNodes/classes/MarkChatItemAsDeletedAction.md)
- [`MarkChatItemsByAuthorAsDeletedAction`](../../YTNodes/classes/MarkChatItemsByAuthorAsDeletedAction.md)
- [`RemoveBannerForLiveChatCommand`](../../YTNodes/classes/RemoveBannerForLiveChatCommand.md)
- [`RemoveChatItemAction`](../../YTNodes/classes/RemoveChatItemAction.md)
- [`RemoveChatItemByAuthorAction`](../../YTNodes/classes/RemoveChatItemByAuthorAction.md)
- [`ReplaceChatItemAction`](../../YTNodes/classes/ReplaceChatItemAction.md)
- [`ReplaceLiveChatAction`](../../YTNodes/classes/ReplaceLiveChatAction.md)
- [`ReplayChatItemAction`](../../YTNodes/classes/ReplayChatItemAction.md)
- [`ShowLiveChatActionPanelAction`](../../YTNodes/classes/ShowLiveChatActionPanelAction.md)
- [`ShowLiveChatDialogAction`](../../YTNodes/classes/ShowLiveChatDialogAction.md)
- [`ShowLiveChatTooltipCommand`](../../YTNodes/classes/ShowLiveChatTooltipCommand.md)
- [`UpdateDateTextAction`](../../YTNodes/classes/UpdateDateTextAction.md)
- [`UpdateDescriptionAction`](../../YTNodes/classes/UpdateDescriptionAction.md)
- [`UpdateLiveChatPollAction`](../../YTNodes/classes/UpdateLiveChatPollAction.md)
- [`UpdateTitleAction`](../../YTNodes/classes/UpdateTitleAction.md)
- [`UpdateToggleButtonTextAction`](../../YTNodes/classes/UpdateToggleButtonTextAction.md)
- [`UpdateViewershipAction`](../../YTNodes/classes/UpdateViewershipAction.md)
- [`LiveChatDialog`](../../YTNodes/classes/LiveChatDialog.md)
- [`LiveChatHeader`](../../YTNodes/classes/LiveChatHeader.md)
- [`LiveChatItemList`](../../YTNodes/classes/LiveChatItemList.md)
- [`LiveChatMessageInput`](../../YTNodes/classes/LiveChatMessageInput.md)
- [`LiveChatParticipant`](../../YTNodes/classes/LiveChatParticipant.md)
- [`LiveChatParticipantsList`](../../YTNodes/classes/LiveChatParticipantsList.md)
- [`LiveStreamability`](../../YTNodes/classes/LiveStreamability.md)
- [`LiveStreamOfflineSlate`](../../YTNodes/classes/LiveStreamOfflineSlate.md)
- [`LockupMetadataView`](../../YTNodes/classes/LockupMetadataView.md)
- [`LockupView`](../../YTNodes/classes/LockupView.md)
- [`MacroMarkersInfoItem`](../../YTNodes/classes/MacroMarkersInfoItem.md)
- [`MacroMarkersList`](../../YTNodes/classes/MacroMarkersList.md)
- [`MacroMarkersListEntity`](../../YTNodes/classes/MacroMarkersListEntity.md)
- [`MacroMarkersListItem`](../../YTNodes/classes/MacroMarkersListItem.md)
- [`Menu`](../../YTNodes/classes/Menu.md)
- [`MenuFlexibleItem`](../../YTNodes/classes/MenuFlexibleItem.md)
- [`MenuPopup`](../../YTNodes/classes/MenuPopup.md)
- [`MenuServiceItemDownload`](../../YTNodes/classes/MenuServiceItemDownload.md)
- [`MultiPageMenu`](../../YTNodes/classes/MultiPageMenu.md)
- [`MultiPageMenuNotificationSection`](../../YTNodes/classes/MultiPageMenuNotificationSection.md)
- [`MusicMenuItemDivider`](../../YTNodes/classes/MusicMenuItemDivider.md)
- [`MusicMultiSelectMenu`](../../YTNodes/classes/MusicMultiSelectMenu.md)
- [`MusicMultiSelectMenuItem`](../../YTNodes/classes/MusicMultiSelectMenuItem.md)
- [`SimpleMenuHeader`](../../YTNodes/classes/SimpleMenuHeader.md)
- [`MenuTitle`](../../YTNodes/classes/MenuTitle.md)
- [`MerchandiseItem`](../../YTNodes/classes/MerchandiseItem.md)
- [`MerchandiseShelf`](../../YTNodes/classes/MerchandiseShelf.md)
- [`Message`](../../YTNodes/classes/Message.md)
- [`MetadataBadge`](../../YTNodes/classes/MetadataBadge.md)
- [`MetadataRow`](../../YTNodes/classes/MetadataRow.md)
- [`MetadataRowContainer`](../../YTNodes/classes/MetadataRowContainer.md)
- [`MetadataRowHeader`](../../YTNodes/classes/MetadataRowHeader.md)
- [`MetadataScreen`](../../YTNodes/classes/MetadataScreen.md)
- [`MicroformatData`](../../YTNodes/classes/MicroformatData.md)
- [`ModalWithTitleAndButton`](../../YTNodes/classes/ModalWithTitleAndButton.md)
- [`Movie`](../../YTNodes/classes/Movie.md)
- [`MovingThumbnail`](../../YTNodes/classes/MovingThumbnail.md)
- [`MultiMarkersPlayerBar`](../../YTNodes/classes/MultiMarkersPlayerBar.md)
- [`MusicCardShelf`](../../YTNodes/classes/MusicCardShelf.md)
- [`MusicCardShelfHeaderBasic`](../../YTNodes/classes/MusicCardShelfHeaderBasic.md)
- [`MusicCarouselShelf`](../../YTNodes/classes/MusicCarouselShelf.md)
- [`MusicCarouselShelfBasicHeader`](../../YTNodes/classes/MusicCarouselShelfBasicHeader.md)
- [`MusicDescriptionShelf`](../../YTNodes/classes/MusicDescriptionShelf.md)
- [`MusicDetailHeader`](../../YTNodes/classes/MusicDetailHeader.md)
- [`MusicDownloadStateBadge`](../../YTNodes/classes/MusicDownloadStateBadge.md)
- [`MusicEditablePlaylistDetailHeader`](../../YTNodes/classes/MusicEditablePlaylistDetailHeader.md)
- [`MusicElementHeader`](../../YTNodes/classes/MusicElementHeader.md)
- [`MusicHeader`](../../YTNodes/classes/MusicHeader.md)
- [`MusicImmersiveHeader`](../../YTNodes/classes/MusicImmersiveHeader.md)
- [`MusicInlineBadge`](../../YTNodes/classes/MusicInlineBadge.md)
- [`MusicItemThumbnailOverlay`](../../YTNodes/classes/MusicItemThumbnailOverlay.md)
- [`MusicLargeCardItemCarousel`](../../YTNodes/classes/MusicLargeCardItemCarousel.md)
- [`MusicMultiRowListItem`](../../YTNodes/classes/MusicMultiRowListItem.md)
- [`MusicNavigationButton`](../../YTNodes/classes/MusicNavigationButton.md)
- [`MusicPlayButton`](../../YTNodes/classes/MusicPlayButton.md)
- [`MusicPlaylistEditHeader`](../../YTNodes/classes/MusicPlaylistEditHeader.md)
- [`MusicPlaylistShelf`](../../YTNodes/classes/MusicPlaylistShelf.md)
- [`MusicQueue`](../../YTNodes/classes/MusicQueue.md)
- [`MusicResponsiveHeader`](../../YTNodes/classes/MusicResponsiveHeader.md)
- [`MusicResponsiveListItem`](../../YTNodes/classes/MusicResponsiveListItem.md)
- [`MusicResponsiveListItemFixedColumn`](../../YTNodes/classes/MusicResponsiveListItemFixedColumn.md)
- [`MusicResponsiveListItemFlexColumn`](../../YTNodes/classes/MusicResponsiveListItemFlexColumn.md)
- [`MusicShelf`](../../YTNodes/classes/MusicShelf.md)
- [`MusicSideAlignedItem`](../../YTNodes/classes/MusicSideAlignedItem.md)
- [`MusicSortFilterButton`](../../YTNodes/classes/MusicSortFilterButton.md)
- [`MusicTastebuilderShelf`](../../YTNodes/classes/MusicTastebuilderShelf.md)
- [`MusicTastebuilderShelfThumbnail`](../../YTNodes/classes/MusicTastebuilderShelfThumbnail.md)
- [`MusicThumbnail`](../../YTNodes/classes/MusicThumbnail.md)
- [`MusicTwoRowItem`](../../YTNodes/classes/MusicTwoRowItem.md)
- [`MusicVisualHeader`](../../YTNodes/classes/MusicVisualHeader.md)
- [`MobileTopbar`](../../YTNodes/classes/MobileTopbar.md)
- [`MultiPageMenuSection`](../../YTNodes/classes/MultiPageMenuSection.md)
- [`PivotBar`](../../YTNodes/classes/PivotBar.md)
- [`PivotBarItem`](../../YTNodes/classes/PivotBarItem.md)
- [`TopbarMenuButton`](../../YTNodes/classes/TopbarMenuButton.md)
- [`NavigationEndpoint`](../../YTNodes/classes/NavigationEndpoint.md)
- [`Notification`](../../YTNodes/classes/Notification.md)
- [`NotificationAction`](../../YTNodes/classes/NotificationAction.md)
- [`OpenOnePickAddVideoModalCommand`](../../YTNodes/classes/OpenOnePickAddVideoModalCommand.md)
- [`PageHeader`](../../YTNodes/classes/PageHeader.md)
- [`PageHeaderView`](../../YTNodes/classes/PageHeaderView.md)
- [`PageIndicatorView`](../../YTNodes/classes/PageIndicatorView.md)
- [`PageIntroduction`](../../YTNodes/classes/PageIntroduction.md)
- [`PanelFooterView`](../../YTNodes/classes/PanelFooterView.md)
- [`PivotButton`](../../YTNodes/classes/PivotButton.md)
- [`PlayerAnnotationsExpanded`](../../YTNodes/classes/PlayerAnnotationsExpanded.md)
- [`PlayerCaptchaView`](../../YTNodes/classes/PlayerCaptchaView.md)
- [`PlayerCaptionsTracklist`](../../YTNodes/classes/PlayerCaptionsTracklist.md)
- [`PlayerControlsOverlay`](../../YTNodes/classes/PlayerControlsOverlay.md)
- [`PlayerErrorMessage`](../../YTNodes/classes/PlayerErrorMessage.md)
- [`PlayerLegacyDesktopYpcOffer`](../../YTNodes/classes/PlayerLegacyDesktopYpcOffer.md)
- [`PlayerLegacyDesktopYpcTrailer`](../../YTNodes/classes/PlayerLegacyDesktopYpcTrailer.md)
- [`PlayerLiveStoryboardSpec`](../../YTNodes/classes/PlayerLiveStoryboardSpec.md)
- [`PlayerMicroformat`](../../YTNodes/classes/PlayerMicroformat.md)
- [`PlayerOverflow`](../../YTNodes/classes/PlayerOverflow.md)
- [`PlayerOverlay`](../../YTNodes/classes/PlayerOverlay.md)
- [`PlayerOverlayAutoplay`](../../YTNodes/classes/PlayerOverlayAutoplay.md)
- [`PlayerOverlayVideoDetails`](../../YTNodes/classes/PlayerOverlayVideoDetails.md)
- [`PlayerStoryboardSpec`](../../YTNodes/classes/PlayerStoryboardSpec.md)
- [`Playlist`](../../YTNodes/classes/Playlist.md)
- [`PlaylistAddToOption`](../../YTNodes/classes/PlaylistAddToOption.md)
- [`PlaylistCollaborationView`](../../YTNodes/classes/PlaylistCollaborationView.md)
- [`PlaylistCustomThumbnail`](../../YTNodes/classes/PlaylistCustomThumbnail.md)
- [`PlaylistHeader`](../../YTNodes/classes/PlaylistHeader.md)
- [`PlaylistInfoCardContent`](../../YTNodes/classes/PlaylistInfoCardContent.md)
- [`PlaylistMetadata`](../../YTNodes/classes/PlaylistMetadata.md)
- [`PlaylistPanel`](../../YTNodes/classes/PlaylistPanel.md)
- [`PlaylistPanelVideo`](../../YTNodes/classes/PlaylistPanelVideo.md)
- [`PlaylistPanelVideoWrapper`](../../YTNodes/classes/PlaylistPanelVideoWrapper.md)
- [`PlaylistSidebar`](../../YTNodes/classes/PlaylistSidebar.md)
- [`PlaylistSidebarPrimaryInfo`](../../YTNodes/classes/PlaylistSidebarPrimaryInfo.md)
- [`PlaylistSidebarSecondaryInfo`](../../YTNodes/classes/PlaylistSidebarSecondaryInfo.md)
- [`PlaylistThumbnailOverlay`](../../YTNodes/classes/PlaylistThumbnailOverlay.md)
- [`PlaylistVideo`](../../YTNodes/classes/PlaylistVideo.md)
- [`PlaylistVideoList`](../../YTNodes/classes/PlaylistVideoList.md)
- [`PlaylistVideoThumbnail`](../../YTNodes/classes/PlaylistVideoThumbnail.md)
- [`Poll`](../../YTNodes/classes/Poll.md)
- [`PostMultiImage`](../../YTNodes/classes/PostMultiImage.md)
- [`PremiereTrailerBadge`](../../YTNodes/classes/PremiereTrailerBadge.md)
- [`ProductList`](../../YTNodes/classes/ProductList.md)
- [`ProductListHeader`](../../YTNodes/classes/ProductListHeader.md)
- [`ProductListItem`](../../YTNodes/classes/ProductListItem.md)
- [`ProfileColumn`](../../YTNodes/classes/ProfileColumn.md)
- [`ProfileColumnStats`](../../YTNodes/classes/ProfileColumnStats.md)
- [`ProfileColumnStatsEntry`](../../YTNodes/classes/ProfileColumnStatsEntry.md)
- [`ProfileColumnUserInfo`](../../YTNodes/classes/ProfileColumnUserInfo.md)
- [`Quiz`](../../YTNodes/classes/Quiz.md)
- [`RecognitionShelf`](../../YTNodes/classes/RecognitionShelf.md)
- [`ReelItem`](../../YTNodes/classes/ReelItem.md)
- [`ReelPlayerHeader`](../../YTNodes/classes/ReelPlayerHeader.md)
- [`ReelPlayerOverlay`](../../YTNodes/classes/ReelPlayerOverlay.md)
- [`ReelShelf`](../../YTNodes/classes/ReelShelf.md)
- [`RelatedChipCloud`](../../YTNodes/classes/RelatedChipCloud.md)
- [`RichGrid`](../../YTNodes/classes/RichGrid.md)
- [`RichItem`](../../YTNodes/classes/RichItem.md)
- [`RichListHeader`](../../YTNodes/classes/RichListHeader.md)
- [`RichMetadata`](../../YTNodes/classes/RichMetadata.md)
- [`RichMetadataRow`](../../YTNodes/classes/RichMetadataRow.md)
- [`RichSection`](../../YTNodes/classes/RichSection.md)
- [`RichShelf`](../../YTNodes/classes/RichShelf.md)
- [`SearchBox`](../../YTNodes/classes/SearchBox.md)
- [`SearchFilter`](../../YTNodes/classes/SearchFilter.md)
- [`SearchFilterGroup`](../../YTNodes/classes/SearchFilterGroup.md)
- [`SearchFilterOptionsDialog`](../../YTNodes/classes/SearchFilterOptionsDialog.md)
- [`SearchHeader`](../../YTNodes/classes/SearchHeader.md)
- [`SearchRefinementCard`](../../YTNodes/classes/SearchRefinementCard.md)
- [`SearchSubMenu`](../../YTNodes/classes/SearchSubMenu.md)
- [`SearchSuggestion`](../../YTNodes/classes/SearchSuggestion.md)
- [`SearchSuggestionsSection`](../../YTNodes/classes/SearchSuggestionsSection.md)
- [`SecondarySearchContainer`](../../YTNodes/classes/SecondarySearchContainer.md)
- [`SectionHeaderView`](../../YTNodes/classes/SectionHeaderView.md)
- [`SectionList`](../../YTNodes/classes/SectionList.md)
- [`SegmentedLikeDislikeButton`](../../YTNodes/classes/SegmentedLikeDislikeButton.md)
- [`SegmentedLikeDislikeButtonView`](../../YTNodes/classes/SegmentedLikeDislikeButtonView.md)
- [`SettingBoolean`](../../YTNodes/classes/SettingBoolean.md)
- [`SettingsCheckbox`](../../YTNodes/classes/SettingsCheckbox.md)
- [`SettingsOptions`](../../YTNodes/classes/SettingsOptions.md)
- [`SettingsSidebar`](../../YTNodes/classes/SettingsSidebar.md)
- [`SettingsSwitch`](../../YTNodes/classes/SettingsSwitch.md)
- [`SharedPost`](../../YTNodes/classes/SharedPost.md)
- [`SharePanelHeader`](../../YTNodes/classes/SharePanelHeader.md)
- [`SharePanelTitleV15`](../../YTNodes/classes/SharePanelTitleV15.md)
- [`ShareTarget`](../../YTNodes/classes/ShareTarget.md)
- [`SheetView`](../../YTNodes/classes/SheetView.md)
- [`Shelf`](../../YTNodes/classes/Shelf.md)
- [`ShortsLockupView`](../../YTNodes/classes/ShortsLockupView.md)
- [`ShowCustomThumbnail`](../../YTNodes/classes/ShowCustomThumbnail.md)
- [`ShowingResultsFor`](../../YTNodes/classes/ShowingResultsFor.md)
- [`SimpleCardContent`](../../YTNodes/classes/SimpleCardContent.md)
- [`SimpleCardTeaser`](../../YTNodes/classes/SimpleCardTeaser.md)
- [`SimpleTextSection`](../../YTNodes/classes/SimpleTextSection.md)
- [`SingleActionEmergencySupport`](../../YTNodes/classes/SingleActionEmergencySupport.md)
- [`SingleColumnBrowseResults`](../../YTNodes/classes/SingleColumnBrowseResults.md)
- [`SingleColumnMusicWatchNextResults`](../../YTNodes/classes/SingleColumnMusicWatchNextResults.md)
- [`SingleHeroImage`](../../YTNodes/classes/SingleHeroImage.md)
- [`SlimOwner`](../../YTNodes/classes/SlimOwner.md)
- [`SlimVideoMetadata`](../../YTNodes/classes/SlimVideoMetadata.md)
- [`SortFilterHeader`](../../YTNodes/classes/SortFilterHeader.md)
- [`SortFilterSubMenu`](../../YTNodes/classes/SortFilterSubMenu.md)
- [`StartAt`](../../YTNodes/classes/StartAt.md)
- [`StructuredDescriptionContent`](../../YTNodes/classes/StructuredDescriptionContent.md)
- [`StructuredDescriptionPlaylistLockup`](../../YTNodes/classes/StructuredDescriptionPlaylistLockup.md)
- [`SubFeedOption`](../../YTNodes/classes/SubFeedOption.md)
- [`SubFeedSelector`](../../YTNodes/classes/SubFeedSelector.md)
- [`SubscribeButton`](../../YTNodes/classes/SubscribeButton.md)
- [`SubscribeButtonView`](../../YTNodes/classes/SubscribeButtonView.md)
- [`SubscriptionNotificationToggleButton`](../../YTNodes/classes/SubscriptionNotificationToggleButton.md)
- [`Tab`](../../YTNodes/classes/Tab.md)
- [`Tabbed`](../../YTNodes/classes/Tabbed.md)
- [`TabbedSearchResults`](../../YTNodes/classes/TabbedSearchResults.md)
- [`TextCarouselItemView`](../../YTNodes/classes/TextCarouselItemView.md)
- [`TextFieldView`](../../YTNodes/classes/TextFieldView.md)
- [`TextHeader`](../../YTNodes/classes/TextHeader.md)
- [`ThirdPartyShareTargetSection`](../../YTNodes/classes/ThirdPartyShareTargetSection.md)
- [`ThumbnailBadgeView`](../../YTNodes/classes/ThumbnailBadgeView.md)
- [`ThumbnailBottomOverlayView`](../../YTNodes/classes/ThumbnailBottomOverlayView.md)
- [`ThumbnailHoverOverlayToggleActionsView`](../../YTNodes/classes/ThumbnailHoverOverlayToggleActionsView.md)
- [`ThumbnailHoverOverlayView`](../../YTNodes/classes/ThumbnailHoverOverlayView.md)
- [`ThumbnailLandscapePortrait`](../../YTNodes/classes/ThumbnailLandscapePortrait.md)
- [`ThumbnailOverlayAvatarStackView`](../../YTNodes/classes/ThumbnailOverlayAvatarStackView.md)
- [`ThumbnailOverlayBadgeView`](../../YTNodes/classes/ThumbnailOverlayBadgeView.md)
- [`ThumbnailOverlayBottomPanel`](../../YTNodes/classes/ThumbnailOverlayBottomPanel.md)
- [`ThumbnailOverlayEndorsement`](../../YTNodes/classes/ThumbnailOverlayEndorsement.md)
- [`ThumbnailOverlayHoverText`](../../YTNodes/classes/ThumbnailOverlayHoverText.md)
- [`ThumbnailOverlayInlineUnplayable`](../../YTNodes/classes/ThumbnailOverlayInlineUnplayable.md)
- [`ThumbnailOverlayLoadingPreview`](../../YTNodes/classes/ThumbnailOverlayLoadingPreview.md)
- [`ThumbnailOverlayNowPlaying`](../../YTNodes/classes/ThumbnailOverlayNowPlaying.md)
- [`ThumbnailOverlayPinking`](../../YTNodes/classes/ThumbnailOverlayPinking.md)
- [`ThumbnailOverlayPlaybackStatus`](../../YTNodes/classes/ThumbnailOverlayPlaybackStatus.md)
- [`ThumbnailOverlayProgressBarView`](../../YTNodes/classes/ThumbnailOverlayProgressBarView.md)
- [`ThumbnailOverlayResumePlayback`](../../YTNodes/classes/ThumbnailOverlayResumePlayback.md)
- [`ThumbnailOverlaySidePanel`](../../YTNodes/classes/ThumbnailOverlaySidePanel.md)
- [`ThumbnailOverlayTimeStatus`](../../YTNodes/classes/ThumbnailOverlayTimeStatus.md)
- [`ThumbnailOverlayTitleView`](../../YTNodes/classes/ThumbnailOverlayTitleView.md)
- [`ThumbnailOverlayToggleButton`](../../YTNodes/classes/ThumbnailOverlayToggleButton.md)
- [`ThumbnailView`](../../YTNodes/classes/ThumbnailView.md)
- [`TicketEvent`](../../YTNodes/classes/TicketEvent.md)
- [`TicketShelf`](../../YTNodes/classes/TicketShelf.md)
- [`TimedMarkerDecoration`](../../YTNodes/classes/TimedMarkerDecoration.md)
- [`TitleAndButtonListHeader`](../../YTNodes/classes/TitleAndButtonListHeader.md)
- [`ToggleButton`](../../YTNodes/classes/ToggleButton.md)
- [`ToggleButtonView`](../../YTNodes/classes/ToggleButtonView.md)
- [`ToggleFormField`](../../YTNodes/classes/ToggleFormField.md)
- [`ToggleMenuServiceItem`](../../YTNodes/classes/ToggleMenuServiceItem.md)
- [`Tooltip`](../../YTNodes/classes/Tooltip.md)
- [`TopicChannelDetails`](../../YTNodes/classes/TopicChannelDetails.md)
- [`Transcript`](../../YTNodes/classes/Transcript.md)
- [`TranscriptFooter`](../../YTNodes/classes/TranscriptFooter.md)
- [`TranscriptSearchBox`](../../YTNodes/classes/TranscriptSearchBox.md)
- [`TranscriptSearchPanel`](../../YTNodes/classes/TranscriptSearchPanel.md)
- [`TranscriptSectionHeader`](../../YTNodes/classes/TranscriptSectionHeader.md)
- [`TranscriptSegment`](../../YTNodes/classes/TranscriptSegment.md)
- [`TranscriptSegmentList`](../../YTNodes/classes/TranscriptSegmentList.md)
- [`TwoColumnBrowseResults`](../../YTNodes/classes/TwoColumnBrowseResults.md)
- [`TwoColumnSearchResults`](../../YTNodes/classes/TwoColumnSearchResults.md)
- [`TwoColumnWatchNextResults`](../../YTNodes/classes/TwoColumnWatchNextResults.md)
- [`UnifiedSharePanel`](../../YTNodes/classes/UnifiedSharePanel.md)
- [`UniversalWatchCard`](../../YTNodes/classes/UniversalWatchCard.md)
- [`UploadTimeFactoid`](../../YTNodes/classes/UploadTimeFactoid.md)
- [`UpsellDialog`](../../YTNodes/classes/UpsellDialog.md)
- [`VerticalList`](../../YTNodes/classes/VerticalList.md)
- [`VerticalWatchCardList`](../../YTNodes/classes/VerticalWatchCardList.md)
- [`Video`](../../YTNodes/classes/Video.md)
- [`VideoAttributesSectionView`](../../YTNodes/classes/VideoAttributesSectionView.md)
- [`VideoAttributeView`](../../YTNodes/classes/VideoAttributeView.md)
- [`VideoDescriptionCourseSection`](../../YTNodes/classes/VideoDescriptionCourseSection.md)
- [`VideoDescriptionHeader`](../../YTNodes/classes/VideoDescriptionHeader.md)
- [`VideoDescriptionInfocardsSection`](../../YTNodes/classes/VideoDescriptionInfocardsSection.md)
- [`VideoDescriptionMusicSection`](../../YTNodes/classes/VideoDescriptionMusicSection.md)
- [`VideoDescriptionTranscriptSection`](../../YTNodes/classes/VideoDescriptionTranscriptSection.md)
- [`VideoDescriptionYouchatSectionView`](../../YTNodes/classes/VideoDescriptionYouchatSectionView.md)
- [`VideoInfoCardContent`](../../YTNodes/classes/VideoInfoCardContent.md)
- [`VideoMetadataCarouselView`](../../YTNodes/classes/VideoMetadataCarouselView.md)
- [`VideoOwner`](../../YTNodes/classes/VideoOwner.md)
- [`VideoPrimaryInfo`](../../YTNodes/classes/VideoPrimaryInfo.md)
- [`VideoSecondaryInfo`](../../YTNodes/classes/VideoSecondaryInfo.md)
- [`VideoSummaryContentView`](../../YTNodes/classes/VideoSummaryContentView.md)
- [`VideoSummaryParagraphView`](../../YTNodes/classes/VideoSummaryParagraphView.md)
- [`VideoTitleHeaderView`](../../YTNodes/classes/VideoTitleHeaderView.md)
- [`VideoViewCount`](../../YTNodes/classes/VideoViewCount.md)
- [`ViewCountFactoid`](../../YTNodes/classes/ViewCountFactoid.md)
- [`WatchCardCompactVideo`](../../YTNodes/classes/WatchCardCompactVideo.md)
- [`WatchCardHeroVideo`](../../YTNodes/classes/WatchCardHeroVideo.md)
- [`WatchCardRichHeader`](../../YTNodes/classes/WatchCardRichHeader.md)
- [`WatchCardSectionSequence`](../../YTNodes/classes/WatchCardSectionSequence.md)
- [`WatchNextEndScreen`](../../YTNodes/classes/WatchNextEndScreen.md)
- [`YpcTrailer`](../../YTNodes/classes/YpcTrailer.md)
- [`AnchoredSection`](../../YTNodes/classes/AnchoredSection.md)
- [`KidsBlocklistPicker`](../../YTNodes/classes/KidsBlocklistPicker.md)
- [`KidsBlocklistPickerItem`](../../YTNodes/classes/KidsBlocklistPickerItem.md)
- [`KidsCategoriesHeader`](../../YTNodes/classes/KidsCategoriesHeader.md)
- [`KidsCategoryTab`](../../YTNodes/classes/KidsCategoryTab.md)
- [`KidsHomeScreen`](../../YTNodes/classes/KidsHomeScreen.md)

## Constructors

### Constructor

> **new YTNode**(): `YTNode`

Defined in: [src/parser/helpers.ts:10](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/helpers.ts#L10)

#### Returns

`YTNode`

## Properties

### type

> `readonly` **type**: `string`

Defined in: [src/parser/helpers.ts:8](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/helpers.ts#L8)

***

### type

> `readonly` `static` **type**: `string` = `'YTNode'`

Defined in: [src/parser/helpers.ts:7](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/helpers.ts#L7)

## Methods

### as()

> **as**\<`T`, `K`\>(...`types`): `InstanceType`\<`K`\[`number`\]\>

Defined in: [src/parser/helpers.ts:29](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/helpers.ts#L29)

Cast to one of the given types.

#### Type Parameters

##### T

`T` *extends* `YTNode`

##### K

`K` *extends* [`YTNodeConstructor`](../interfaces/YTNodeConstructor.md)\<`T`\>[]

#### Parameters

##### types

...`K`

The types to cast to

#### Returns

`InstanceType`\<`K`\[`number`\]\>

The node cast to one of the given types

#### Throws

If the node is not of the given type

***

### hasKey()

> **hasKey**\<`T`, `R`\>(`key`): `this is YTNode & { [k in string]: R }`

Defined in: [src/parser/helpers.ts:41](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/helpers.ts#L41)

Check for a key without asserting the type.

#### Type Parameters

##### T

`T` *extends* `string`

##### R

`R` = `any`

#### Parameters

##### key

`T`

The key to check

#### Returns

`this is YTNode & { [k in string]: R }`

Whether the node has the key

***

### is()

> **is**\<`T`, `K`\>(...`types`): `this is InstanceType<K[number]>`

Defined in: [src/parser/helpers.ts:19](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/helpers.ts#L19)

Check if the node is of the given type.

#### Type Parameters

##### T

`T` *extends* `YTNode`

##### K

`K` *extends* [`YTNodeConstructor`](../interfaces/YTNodeConstructor.md)\<`T`\>[]

#### Parameters

##### types

...`K`

The type to check

#### Returns

`this is InstanceType<K[number]>`

whether the node is of the given type

***

### key()

> **key**\<`T`, `R`\>(`key`): [`Maybe`](Maybe.md)

Defined in: [src/parser/helpers.ts:51](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/helpers.ts#L51)

Assert that the node has the given key and return it.

#### Type Parameters

##### T

`T` *extends* `string`

##### R

`R` = `any`

#### Parameters

##### key

`T`

The key to check

#### Returns

[`Maybe`](Maybe.md)

The value of the key wrapped in a Maybe

#### Throws

If the node does not have the key
