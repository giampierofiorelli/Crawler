[youtubei.js](../../../../README.md) / [YTNodes](../README.md) / ChannelAboutFullMetadata

# Class: ChannelAboutFullMetadata

Defined in: [src/parser/classes/ChannelAboutFullMetadata.ts:8](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/classes/ChannelAboutFullMetadata.ts#L8)

## Extends

- [`YTNode`](../../Helpers/classes/YTNode.md)

## Constructors

### Constructor

> **new ChannelAboutFullMetadata**(`data`): `ChannelAboutFullMetadata`

Defined in: [src/parser/classes/ChannelAboutFullMetadata.ts:30](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/classes/ChannelAboutFullMetadata.ts#L30)

#### Parameters

##### data

[`RawNode`](../../../../type-aliases/RawNode.md)

#### Returns

`ChannelAboutFullMetadata`

#### Overrides

[`YTNode`](../../Helpers/classes/YTNode.md).[`constructor`](../../Helpers/classes/YTNode.md#constructor)

## Properties

### avatar

> **avatar**: [`Thumbnail`](../../Misc/classes/Thumbnail.md)[]

Defined in: [src/parser/classes/ChannelAboutFullMetadata.ts:13](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/classes/ChannelAboutFullMetadata.ts#L13)

***

### buttons

> **buttons**: [`ObservedArray`](../../Helpers/type-aliases/ObservedArray.md)\<[`Button`](Button.md)\>

Defined in: [src/parser/classes/ChannelAboutFullMetadata.ts:28](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/classes/ChannelAboutFullMetadata.ts#L28)

***

### can\_reveal\_email

> **can\_reveal\_email**: `boolean`

Defined in: [src/parser/classes/ChannelAboutFullMetadata.ts:26](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/classes/ChannelAboutFullMetadata.ts#L26)

***

### canonical\_channel\_url

> **canonical\_channel\_url**: `string`

Defined in: [src/parser/classes/ChannelAboutFullMetadata.ts:14](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/classes/ChannelAboutFullMetadata.ts#L14)

***

### country

> **country**: [`Text`](../../Misc/classes/Text.md)

Defined in: [src/parser/classes/ChannelAboutFullMetadata.ts:27](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/classes/ChannelAboutFullMetadata.ts#L27)

***

### description

> **description**: [`Text`](../../Misc/classes/Text.md)

Defined in: [src/parser/classes/ChannelAboutFullMetadata.ts:24](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/classes/ChannelAboutFullMetadata.ts#L24)

***

### email\_reveal

> **email\_reveal**: [`NavigationEndpoint`](NavigationEndpoint.md)

Defined in: [src/parser/classes/ChannelAboutFullMetadata.ts:25](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/classes/ChannelAboutFullMetadata.ts#L25)

***

### id

> **id**: `string`

Defined in: [src/parser/classes/ChannelAboutFullMetadata.ts:11](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/classes/ChannelAboutFullMetadata.ts#L11)

***

### joined\_date

> **joined\_date**: [`Text`](../../Misc/classes/Text.md)

Defined in: [src/parser/classes/ChannelAboutFullMetadata.ts:23](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/classes/ChannelAboutFullMetadata.ts#L23)

***

### name

> **name**: [`Text`](../../Misc/classes/Text.md)

Defined in: [src/parser/classes/ChannelAboutFullMetadata.ts:12](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/classes/ChannelAboutFullMetadata.ts#L12)

***

### primary\_links

> **primary\_links**: `object`[]

Defined in: [src/parser/classes/ChannelAboutFullMetadata.ts:16](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/classes/ChannelAboutFullMetadata.ts#L16)

#### endpoint

> **endpoint**: [`NavigationEndpoint`](NavigationEndpoint.md)

#### icon

> **icon**: [`Thumbnail`](../../Misc/classes/Thumbnail.md)[]

#### title

> **title**: [`Text`](../../Misc/classes/Text.md)

***

### type

> `readonly` **type**: `string`

Defined in: [src/parser/helpers.ts:8](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/helpers.ts#L8)

#### Inherited from

[`YTNode`](../../Helpers/classes/YTNode.md).[`type`](../../Helpers/classes/YTNode.md#type)

***

### view\_count

> **view\_count**: [`Text`](../../Misc/classes/Text.md)

Defined in: [src/parser/classes/ChannelAboutFullMetadata.ts:22](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/classes/ChannelAboutFullMetadata.ts#L22)

***

### type

> `static` **type**: `string` = `'ChannelAboutFullMetadata'`

Defined in: [src/parser/classes/ChannelAboutFullMetadata.ts:9](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/classes/ChannelAboutFullMetadata.ts#L9)

#### Overrides

[`YTNode`](../../Helpers/classes/YTNode.md).[`type`](../../Helpers/classes/YTNode.md#type-1)

## Methods

### as()

> **as**\<`T`, `K`\>(...`types`): `InstanceType`\<`K`\[`number`\]\>

Defined in: [src/parser/helpers.ts:29](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/helpers.ts#L29)

Cast to one of the given types.

#### Type Parameters

##### T

`T` *extends* [`YTNode`](../../Helpers/classes/YTNode.md)

##### K

`K` *extends* [`YTNodeConstructor`](../../Helpers/interfaces/YTNodeConstructor.md)\<`T`\>[]

#### Parameters

##### types

...`K`

The types to cast to

#### Returns

`InstanceType`\<`K`\[`number`\]\>

The node cast to one of the given types

#### Throws

If the node is not of the given type

#### Inherited from

[`YTNode`](../../Helpers/classes/YTNode.md).[`as`](../../Helpers/classes/YTNode.md#as)

***

### hasKey()

> **hasKey**\<`T`, `R`\>(`key`): `this is ChannelAboutFullMetadata & { [k in string]: R }`

Defined in: [src/parser/helpers.ts:41](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/helpers.ts#L41)

Check for a key without asserting the type.

#### Type Parameters

##### T

`T` *extends* `string`

##### R

`R` = `any`

#### Parameters

##### key

`T`

The key to check

#### Returns

`this is ChannelAboutFullMetadata & { [k in string]: R }`

Whether the node has the key

#### Inherited from

[`YTNode`](../../Helpers/classes/YTNode.md).[`hasKey`](../../Helpers/classes/YTNode.md#haskey)

***

### is()

> **is**\<`T`, `K`\>(...`types`): `this is InstanceType<K[number]>`

Defined in: [src/parser/helpers.ts:19](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/helpers.ts#L19)

Check if the node is of the given type.

#### Type Parameters

##### T

`T` *extends* [`YTNode`](../../Helpers/classes/YTNode.md)

##### K

`K` *extends* [`YTNodeConstructor`](../../Helpers/interfaces/YTNodeConstructor.md)\<`T`\>[]

#### Parameters

##### types

...`K`

The type to check

#### Returns

`this is InstanceType<K[number]>`

whether the node is of the given type

#### Inherited from

[`YTNode`](../../Helpers/classes/YTNode.md).[`is`](../../Helpers/classes/YTNode.md#is)

***

### key()

> **key**\<`T`, `R`\>(`key`): [`Maybe`](../../Helpers/classes/Maybe.md)

Defined in: [src/parser/helpers.ts:51](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/helpers.ts#L51)

Assert that the node has the given key and return it.

#### Type Parameters

##### T

`T` *extends* `string`

##### R

`R` = `any`

#### Parameters

##### key

`T`

The key to check

#### Returns

[`Maybe`](../../Helpers/classes/Maybe.md)

The value of the key wrapped in a Maybe

#### Throws

If the node does not have the key

#### Inherited from

[`YTNode`](../../Helpers/classes/YTNode.md).[`key`](../../Helpers/classes/YTNode.md#key)
