[youtubei.js](../../../../README.md) / [YTNodes](../README.md) / CreatePlaylistServiceEndpoint

# Class: CreatePlaylistServiceEndpoint

Defined in: [src/parser/classes/endpoints/CreatePlaylistServiceEndpoint.ts:6](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/classes/endpoints/CreatePlaylistServiceEndpoint.ts#L6)

## Extends

- [`YTNode`](../../Helpers/classes/YTNode.md)

## Implements

- [`IEndpoint`](../../../../interfaces/IEndpoint.md)\<[`CreatePlaylistServiceRequest`](../../../../type-aliases/CreatePlaylistServiceRequest.md)\>

## Constructors

### Constructor

> **new CreatePlaylistServiceEndpoint**(`data`): `CreatePlaylistServiceEndpoint`

Defined in: [src/parser/classes/endpoints/CreatePlaylistServiceEndpoint.ts:11](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/classes/endpoints/CreatePlaylistServiceEndpoint.ts#L11)

#### Parameters

##### data

[`RawNode`](../../../../type-aliases/RawNode.md)

#### Returns

`CreatePlaylistServiceEndpoint`

#### Overrides

[`YTNode`](../../Helpers/classes/YTNode.md).[`constructor`](../../Helpers/classes/YTNode.md#constructor)

## Properties

### type

> `readonly` **type**: `string`

Defined in: [src/parser/helpers.ts:8](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/helpers.ts#L8)

#### Inherited from

[`YTNode`](../../Helpers/classes/YTNode.md).[`type`](../../Helpers/classes/YTNode.md#type)

***

### type

> `static` **type**: `string` = `'CreatePlaylistServiceEndpoint'`

Defined in: [src/parser/classes/endpoints/CreatePlaylistServiceEndpoint.ts:7](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/classes/endpoints/CreatePlaylistServiceEndpoint.ts#L7)

#### Overrides

[`YTNode`](../../Helpers/classes/YTNode.md).[`type`](../../Helpers/classes/YTNode.md#type-1)

## Methods

### as()

> **as**\<`T`, `K`\>(...`types`): `InstanceType`\<`K`\[`number`\]\>

Defined in: [src/parser/helpers.ts:29](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/helpers.ts#L29)

Cast to one of the given types.

#### Type Parameters

##### T

`T` *extends* [`YTNode`](../../Helpers/classes/YTNode.md)

##### K

`K` *extends* [`YTNodeConstructor`](../../Helpers/interfaces/YTNodeConstructor.md)\<`T`\>[]

#### Parameters

##### types

...`K`

The types to cast to

#### Returns

`InstanceType`\<`K`\[`number`\]\>

The node cast to one of the given types

#### Throws

If the node is not of the given type

#### Inherited from

[`YTNode`](../../Helpers/classes/YTNode.md).[`as`](../../Helpers/classes/YTNode.md#as)

***

### buildRequest()

> **buildRequest**(): [`CreatePlaylistServiceRequest`](../../../../type-aliases/CreatePlaylistServiceRequest.md)

Defined in: [src/parser/classes/endpoints/CreatePlaylistServiceEndpoint.ts:20](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/classes/endpoints/CreatePlaylistServiceEndpoint.ts#L20)

#### Returns

[`CreatePlaylistServiceRequest`](../../../../type-aliases/CreatePlaylistServiceRequest.md)

#### Implementation of

[`IEndpoint`](../../../../interfaces/IEndpoint.md).[`buildRequest`](../../../../interfaces/IEndpoint.md#buildrequest)

***

### getApiPath()

> **getApiPath**(): `string`

Defined in: [src/parser/classes/endpoints/CreatePlaylistServiceEndpoint.ts:16](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/classes/endpoints/CreatePlaylistServiceEndpoint.ts#L16)

#### Returns

`string`

#### Implementation of

[`IEndpoint`](../../../../interfaces/IEndpoint.md).[`getApiPath`](../../../../interfaces/IEndpoint.md#getapipath)

***

### hasKey()

> **hasKey**\<`T`, `R`\>(`key`): `this is CreatePlaylistServiceEndpoint & { [k in string]: R }`

Defined in: [src/parser/helpers.ts:41](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/helpers.ts#L41)

Check for a key without asserting the type.

#### Type Parameters

##### T

`T` *extends* `string`

##### R

`R` = `any`

#### Parameters

##### key

`T`

The key to check

#### Returns

`this is CreatePlaylistServiceEndpoint & { [k in string]: R }`

Whether the node has the key

#### Inherited from

[`YTNode`](../../Helpers/classes/YTNode.md).[`hasKey`](../../Helpers/classes/YTNode.md#haskey)

***

### is()

> **is**\<`T`, `K`\>(...`types`): `this is InstanceType<K[number]>`

Defined in: [src/parser/helpers.ts:19](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/helpers.ts#L19)

Check if the node is of the given type.

#### Type Parameters

##### T

`T` *extends* [`YTNode`](../../Helpers/classes/YTNode.md)

##### K

`K` *extends* [`YTNodeConstructor`](../../Helpers/interfaces/YTNodeConstructor.md)\<`T`\>[]

#### Parameters

##### types

...`K`

The type to check

#### Returns

`this is InstanceType<K[number]>`

whether the node is of the given type

#### Inherited from

[`YTNode`](../../Helpers/classes/YTNode.md).[`is`](../../Helpers/classes/YTNode.md#is)

***

### key()

> **key**\<`T`, `R`\>(`key`): [`Maybe`](../../Helpers/classes/Maybe.md)

Defined in: [src/parser/helpers.ts:51](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/helpers.ts#L51)

Assert that the node has the given key and return it.

#### Type Parameters

##### T

`T` *extends* `string`

##### R

`R` = `any`

#### Parameters

##### key

`T`

The key to check

#### Returns

[`Maybe`](../../Helpers/classes/Maybe.md)

The value of the key wrapped in a Maybe

#### Throws

If the node does not have the key

#### Inherited from

[`YTNode`](../../Helpers/classes/YTNode.md).[`key`](../../Helpers/classes/YTNode.md#key)
