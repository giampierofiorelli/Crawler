[youtubei.js](../../../../README.md) / [Types](../README.md) / SearchFilters

# Type Alias: SearchFilters

> **SearchFilters** = `object`

Defined in: [src/types/Misc.ts:13](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/types/Misc.ts#L13)

## Properties

### duration?

> `optional` **duration?**: [`Duration`](Duration.md)

Defined in: [src/types/Misc.ts:16](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/types/Misc.ts#L16)

***

### features?

> `optional` **features?**: [`Feature`](Feature.md)[]

Defined in: [src/types/Misc.ts:18](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/types/Misc.ts#L18)

***

### prioritize?

> `optional` **prioritize?**: [`Prioritize`](Prioritize.md)

Defined in: [src/types/Misc.ts:17](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/types/Misc.ts#L17)

***

### type?

> `optional` **type?**: [`SearchType`](SearchType.md)

Defined in: [src/types/Misc.ts:15](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/types/Misc.ts#L15)

***

### upload\_date?

> `optional` **upload\_date?**: [`UploadDate`](UploadDate.md)

Defined in: [src/types/Misc.ts:14](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/types/Misc.ts#L14)
