[youtubei.js](../../../../README.md) / [Misc](../README.md) / RendererContext

# Class: RendererContext

Defined in: [src/parser/classes/misc/RendererContext.ts:5](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/classes/misc/RendererContext.ts#L5)

## Constructors

### Constructor

> **new RendererContext**(`data?`): `RendererContext`

Defined in: [src/parser/classes/misc/RendererContext.ts:9](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/classes/misc/RendererContext.ts#L9)

#### Parameters

##### data?

[`RawNode`](../../../../type-aliases/RawNode.md)

#### Returns

`RendererContext`

## Properties

### accessibility\_context?

> `optional` **accessibility\_context?**: [`AccessibilityContext`](AccessibilityContext.md)

Defined in: [src/parser/classes/misc/RendererContext.ts:7](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/classes/misc/RendererContext.ts#L7)

***

### command\_context?

> `optional` **command\_context?**: [`CommandContext`](CommandContext.md)

Defined in: [src/parser/classes/misc/RendererContext.ts:6](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/classes/misc/RendererContext.ts#L6)
