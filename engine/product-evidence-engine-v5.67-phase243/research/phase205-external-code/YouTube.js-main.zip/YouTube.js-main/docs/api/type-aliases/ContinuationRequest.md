[youtubei.js](../README.md) / ContinuationRequest

# Type Alias: ContinuationRequest

> **ContinuationRequest** = `object`

Defined in: [src/parser/types/CommandEndpoints.ts:143](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/types/CommandEndpoints.ts#L143)

## Properties

### continuation?

> `optional` **continuation?**: `string`

Defined in: [src/parser/types/CommandEndpoints.ts:145](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/types/CommandEndpoints.ts#L145)

***

### fetchCommentsParams?

> `optional` **fetchCommentsParams?**: `object`

Defined in: [src/parser/types/CommandEndpoints.ts:147](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/types/CommandEndpoints.ts#L147)

#### continuation

> **continuation**: `string`

***

### formData?

> `optional` **formData?**: [`FormData`](FormData.md)

Defined in: [src/parser/types/CommandEndpoints.ts:144](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/types/CommandEndpoints.ts#L144)

***

### notificationsMenuRequestType?

> `optional` **notificationsMenuRequestType?**: `string`

Defined in: [src/parser/types/CommandEndpoints.ts:146](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/types/CommandEndpoints.ts#L146)
