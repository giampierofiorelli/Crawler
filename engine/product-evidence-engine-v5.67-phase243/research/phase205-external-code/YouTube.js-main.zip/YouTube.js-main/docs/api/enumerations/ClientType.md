[youtubei.js](../README.md) / ClientType

# Enumeration: ClientType

Defined in: [src/core/Session.ts:22](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/core/Session.ts#L22)

## Enumeration Members

### ANDROID

> **ANDROID**: `"ANDROID"`

Defined in: [src/core/Session.ts:28](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/core/Session.ts#L28)

***

### ANDROID\_CREATOR

> **ANDROID\_CREATOR**: `"ANDROID_CREATOR"`

Defined in: [src/core/Session.ts:32](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/core/Session.ts#L32)

***

### ANDROID\_MUSIC

> **ANDROID\_MUSIC**: `"ANDROID_MUSIC"`

Defined in: [src/core/Session.ts:31](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/core/Session.ts#L31)

***

### ANDROID\_VR

> **ANDROID\_VR**: `"ANDROID_VR"`

Defined in: [src/core/Session.ts:29](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/core/Session.ts#L29)

***

### IOS

> **IOS**: `"iOS"`

Defined in: [src/core/Session.ts:27](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/core/Session.ts#L27)

***

### KIDS

> **KIDS**: `"WEB_KIDS"`

Defined in: [src/core/Session.ts:25](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/core/Session.ts#L25)

***

### MUSIC

> **MUSIC**: `"WEB_REMIX"`

Defined in: [src/core/Session.ts:26](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/core/Session.ts#L26)

***

### MWEB

> **MWEB**: `"MWEB"`

Defined in: [src/core/Session.ts:24](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/core/Session.ts#L24)

***

### TV

> **TV**: `"TVHTML5"`

Defined in: [src/core/Session.ts:33](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/core/Session.ts#L33)

***

### TV\_EMBEDDED

> **TV\_EMBEDDED**: `"TVHTML5_SIMPLY_EMBEDDED_PLAYER"`

Defined in: [src/core/Session.ts:35](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/core/Session.ts#L35)

***

### TV\_SIMPLY

> **TV\_SIMPLY**: `"TVHTML5_SIMPLY"`

Defined in: [src/core/Session.ts:34](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/core/Session.ts#L34)

***

### VISIONOS

> **VISIONOS**: `"VISIONOS"`

Defined in: [src/core/Session.ts:30](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/core/Session.ts#L30)

***

### WEB

> **WEB**: `"WEB"`

Defined in: [src/core/Session.ts:23](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/core/Session.ts#L23)

***

### WEB\_CREATOR

> **WEB\_CREATOR**: `"WEB_CREATOR"`

Defined in: [src/core/Session.ts:37](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/core/Session.ts#L37)

***

### WEB\_EMBEDDED

> **WEB\_EMBEDDED**: `"WEB_EMBEDDED_PLAYER"`

Defined in: [src/core/Session.ts:36](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/core/Session.ts#L36)
