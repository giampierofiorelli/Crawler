[youtubei.js](../README.md) / SearchRequest

# Type Alias: SearchRequest

> **SearchRequest** = `object`

Defined in: [src/parser/types/CommandEndpoints.ts:117](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/types/CommandEndpoints.ts#L117)

## Properties

### params?

> `optional` **params?**: `string`

Defined in: [src/parser/types/CommandEndpoints.ts:119](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/types/CommandEndpoints.ts#L119)

***

### query?

> `optional` **query?**: `string`

Defined in: [src/parser/types/CommandEndpoints.ts:118](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/types/CommandEndpoints.ts#L118)

***

### suggestStats?

> `optional` **suggestStats?**: `unknown`

Defined in: [src/parser/types/CommandEndpoints.ts:121](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/types/CommandEndpoints.ts#L121)

***

### webSearchboxStatsUrl?

> `optional` **webSearchboxStatsUrl?**: `string`

Defined in: [src/parser/types/CommandEndpoints.ts:120](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/types/CommandEndpoints.ts#L120)
