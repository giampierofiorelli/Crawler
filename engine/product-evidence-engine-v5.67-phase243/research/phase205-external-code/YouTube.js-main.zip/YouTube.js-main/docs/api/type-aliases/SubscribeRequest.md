[youtubei.js](../README.md) / SubscribeRequest

# Type Alias: SubscribeRequest

> **SubscribeRequest** = `object`

Defined in: [src/parser/types/CommandEndpoints.ts:124](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/types/CommandEndpoints.ts#L124)

## Properties

### botguardResponse?

> `optional` **botguardResponse?**: `string`

Defined in: [src/parser/types/CommandEndpoints.ts:128](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/types/CommandEndpoints.ts#L128)

***

### channelIds?

> `optional` **channelIds?**: `string`[]

Defined in: [src/parser/types/CommandEndpoints.ts:125](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/types/CommandEndpoints.ts#L125)

***

### clientFeature?

> `optional` **clientFeature?**: `string`

Defined in: [src/parser/types/CommandEndpoints.ts:129](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/types/CommandEndpoints.ts#L129)

***

### params?

> `optional` **params?**: `string`

Defined in: [src/parser/types/CommandEndpoints.ts:127](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/types/CommandEndpoints.ts#L127)

***

### siloName?

> `optional` **siloName?**: `string`

Defined in: [src/parser/types/CommandEndpoints.ts:126](https://github.com/LuanRT/YouTube.js/blob/06bfc6afd419ea622aac9ce491b749456ebda028/src/parser/types/CommandEndpoints.ts#L126)
